#include "gl/Model.h"

#include <cstring>
#include <filesystem>
#include <iostream>

#include "glm/gtc/type_ptr.hpp"
#include "glm/gtc/quaternion.hpp"
#include "glm/gtc/matrix_transform.hpp"

namespace {

  // ---- small optional-field helpers ---------------------------------
  // simdjson::dom doesn't have nlohmann's node.find(key)/value(key, default);
  // these wrap the non-throwing `.get(out)` pattern so a missing/optional
  // glTF field just falls back to a default instead of throwing.

  bool HasField(const simdjson::dom::element& p_obj, std::string_view p_key) {
    simdjson::dom::element out;
    return !p_obj[p_key].get(out);
  }

  uint64_t GetUintOr(const simdjson::dom::element& p_obj, std::string_view p_key, uint64_t p_default) {
    uint64_t value = p_default;
    p_obj[p_key].get(value); // leaves `value` untouched (still p_default) on error
    return value;
  }

}

Model::Model(const std::string& p_filepath)
    : c_filepath(p_filepath) {

  c_directory = std::filesystem::path(p_filepath).parent_path().string();

  // parser.load() reads + parses the .gltf file in one step; c_parser owns
  // the underlying buffer for as long as this Model (and therefore c_json,
  // which is just a view into it) is alive.
  c_json = c_parser.load(c_filepath);

  c_binaryData = LoadBinaryData();

  // glTF's "scene" root is conventionally node 0 for these simple single-scene
  // assets; a fuller loader would read JSON["scene"] / JSON["scenes"] to find
  // the actual root node(s).
  TraverseNode(0);
}

std::vector<unsigned char> Model::LoadBinaryData() {
  std::string uri = std::string(std::string_view(c_json["buffers"].at(0)["uri"]));

  std::string binPath = c_directory.empty() ? uri : (c_directory + "/" + uri);

  std::string bytesText = get_file_contents(binPath.c_str());

  return std::vector<unsigned char>(bytesText.begin(), bytesText.end());
}

void Model::TraverseNode(unsigned int p_nodeIndex, const glm::mat4& p_parentTransform) {
  simdjson::dom::element node = c_json["nodes"].at(p_nodeIndex);

  glm::vec3 translation(0.0f);
  if (HasField(node, "translation")) {
    simdjson::dom::array t = node["translation"].get_array();
    translation = glm::vec3((double)t.at(0), (double)t.at(1), (double)t.at(2));
  }

  glm::quat rotation(1.0f, 0.0f, 0.0f, 0.0f);
  if (HasField(node, "rotation")) {
    simdjson::dom::array r = node["rotation"].get_array();
    // glTF stores quaternions as [x, y, z, w]; glm::quat's constructor wants (w, x, y, z)
    rotation = glm::quat((float)(double)r.at(3), (float)(double)r.at(0),
                          (float)(double)r.at(1), (float)(double)r.at(2));
  }

  glm::vec3 scale(1.0f);
  if (HasField(node, "scale")) {
    simdjson::dom::array s = node["scale"].get_array();
    scale = glm::vec3((double)s.at(0), (double)s.at(1), (double)s.at(2));
  }

  glm::mat4 matNode(1.0f);
  if (HasField(node, "matrix")) {
    simdjson::dom::array m = node["matrix"].get_array();
    float values[16];
    for (unsigned int i = 0; i < 16; i++) values[i] = (float)(double)m.at(i);
    matNode = glm::make_mat4(values);
  }

  glm::mat4 trans = glm::translate(glm::mat4(1.0f), translation);
  glm::mat4 rot = glm::mat4_cast(rotation);
  glm::mat4 sca = glm::scale(glm::mat4(1.0f), scale);

  glm::mat4 matNextNode = p_parentTransform * matNode * trans * rot * sca;

  if (HasField(node, "mesh")) {
    uint64_t meshIndex = node["mesh"];
    LoadMesh((unsigned int)meshIndex, matNextNode);
  }

  if (HasField(node, "children")) {
    simdjson::dom::array children = node["children"].get_array();
    for (simdjson::dom::element child : children) {
      uint64_t childIndex = child;
      TraverseNode((unsigned int)childIndex, matNextNode);
    }
  }
}

void Model::LoadMesh(unsigned int p_meshIndex, const glm::mat4& p_transform) {
  simdjson::dom::element primitive = c_json["meshes"].at(p_meshIndex)["primitives"].at(0);
  simdjson::dom::element attributes = primitive["attributes"];

  uint64_t posAccInd = attributes["POSITION"];
  uint64_t normalAccInd = attributes["NORMAL"];
  uint64_t texAccInd = attributes["TEXCOORD_0"];
  uint64_t indAccInd = primitive["indices"];

  std::vector<float> posVec = GetFloats(c_json["accessors"].at(posAccInd));
  std::vector<glm::vec3> positions = GroupFloatsVec3(posVec);

  std::vector<float> normalVec = GetFloats(c_json["accessors"].at(normalAccInd));
  std::vector<glm::vec3> normals = GroupFloatsVec3(normalVec);

  std::vector<float> texVec = GetFloats(c_json["accessors"].at(texAccInd));
  std::vector<glm::vec2> texUVs = GroupFloatsVec2(texVec);

  std::vector<Vertex> vertices = AssembleVertices(positions, normals, texUVs);
  std::vector<GLuint> indices = GetIndices(c_json["accessors"].at(indAccInd));

  std::vector<std::shared_ptr<Texture>> textures;
  if (HasField(primitive, "material")) {
    uint64_t materialIndex = primitive["material"];
    textures = GetTextures(c_json["materials"].at(materialIndex));
  }
  // primitives with no "material" field, or materials with no texture
  // (flat baseColorFactor colour instead) correctly end up with an empty
  // texture list here rather than every image in the file.

  auto newMesh = std::make_unique<Mesh>(vertices, indices, textures);
  newMesh->SetTransform(p_transform);

  c_meshes.push_back(std::move(newMesh));
}

std::vector<float> Model::GetFloats(simdjson::dom::element p_accessor) {
  std::vector<float> floatVec;

  uint64_t bufferViewInd = GetUintOr(p_accessor, "bufferView", 0);
  uint64_t count = p_accessor["count"];
  uint64_t accByteOffset = GetUintOr(p_accessor, "byteOffset", 0);
  std::string type = std::string(std::string_view(p_accessor["type"]));

  simdjson::dom::element bufferView = c_json["bufferViews"].at(bufferViewInd);
  uint64_t byteOffset = GetUintOr(bufferView, "byteOffset", 0);

  unsigned int numPerVert;
  if (type == "SCALAR") numPerVert = 1;
  else if (type == "VEC2") numPerVert = 2;
  else if (type == "VEC3") numPerVert = 3;
  else if (type == "VEC4") numPerVert = 4;
  else throw std::invalid_argument("Type is invalid (not SCALAR, VEC2, VEC3, or VEC4)");

  size_t beginningOfData = byteOffset + accByteOffset;
  size_t lengthOfData = count * 4 * numPerVert;

  for (size_t i = beginningOfData; i < beginningOfData + lengthOfData; ) {
    unsigned char bytes[] = { c_binaryData[i++], c_binaryData[i++], c_binaryData[i++], c_binaryData[i++] };
    float value;
    std::memcpy(&value, bytes, sizeof(float));
    floatVec.push_back(value);
  }

  return floatVec;
}

std::vector<GLuint> Model::GetIndices(simdjson::dom::element p_accessor) {
  std::vector<GLuint> indices;

  uint64_t bufferViewInd = GetUintOr(p_accessor, "bufferView", 0);
  uint64_t count = p_accessor["count"];
  uint64_t accByteOffset = GetUintOr(p_accessor, "byteOffset", 0);
  uint64_t componentType = p_accessor["componentType"];

  simdjson::dom::element bufferView = c_json["bufferViews"].at(bufferViewInd);
  uint64_t byteOffset = GetUintOr(bufferView, "byteOffset", 0);

  size_t beginningOfData = byteOffset + accByteOffset;

  // glTF component type codes (see spec, "Accessor Data Types"):
  //   5121 = UNSIGNED_BYTE, 5123 = UNSIGNED_SHORT, 5125 = UNSIGNED_INT
  if (componentType == 5125) {
    for (size_t i = beginningOfData; i < beginningOfData + count * 4; ) {
      unsigned char bytes[] = { c_binaryData[i++], c_binaryData[i++], c_binaryData[i++], c_binaryData[i++] };
      unsigned int value;
      std::memcpy(&value, bytes, sizeof(unsigned int));
      indices.push_back((GLuint)value);
    }
  } else if (componentType == 5123) {
    for (size_t i = beginningOfData; i < beginningOfData + count * 2; ) {
      unsigned char bytes[] = { c_binaryData[i++], c_binaryData[i++] };
      unsigned short value;
      std::memcpy(&value, bytes, sizeof(unsigned short));
      indices.push_back((GLuint)value);
    }
  } else if (componentType == 5121) {
    for (size_t i = beginningOfData; i < beginningOfData + count; i++) {
      indices.push_back((GLuint)c_binaryData[i]);
    }
  }

  return indices;
}

std::shared_ptr<Texture> Model::LoadTextureByIndex(uint64_t p_textureIndex, const std::string& p_textureType) {
  uint64_t imageIndex = c_json["textures"].at(p_textureIndex)["source"];
  simdjson::dom::element image = c_json["images"].at(imageIndex);

  std::string uri = std::string(std::string_view(image["uri"]));
  std::string texPath = c_directory.empty() ? uri : (c_directory + "/" + uri);

  auto cached = c_loadedTextures.find(texPath);
  if (cached != c_loadedTextures.end()) {
    return cached->second;
  }

  auto texture = std::make_shared<Texture>(
      texPath, p_textureType, (GLuint)c_loadedTextures.size(), GL_RGBA, GL_UNSIGNED_BYTE);

  c_loadedTextures[texPath] = texture;
  return texture;
}

std::vector<std::shared_ptr<Texture>> Model::GetTextures(simdjson::dom::element p_material) {
  std::vector<std::shared_ptr<Texture>> textures;

  if (!HasField(p_material, "pbrMetallicRoughness")) return textures;
  simdjson::dom::element pbr = p_material["pbrMetallicRoughness"];

  if (HasField(pbr, "baseColorTexture")) {
    uint64_t texIndex = pbr["baseColorTexture"]["index"];
    textures.push_back(LoadTextureByIndex(texIndex, "diffuse_tex_type"));
  }

  if (HasField(pbr, "metallicRoughnessTexture")) {
    uint64_t texIndex = pbr["metallicRoughnessTexture"]["index"];
    textures.push_back(LoadTextureByIndex(texIndex, "specular_tex_type"));
  }

  // materials with neither (flat baseColorFactor colour, no texture) fall
  // through to here with an empty textures vector - intentional, not a bug.
  return textures;
}

std::vector<Vertex> Model::AssembleVertices(
    const std::vector<glm::vec3>& p_positions,
    const std::vector<glm::vec3>& p_normals,
    const std::vector<glm::vec2>& p_texUVs) {

  std::vector<Vertex> vertices;
  for (size_t i = 0; i < p_positions.size(); i++) {
    Vertex v;
    v.position = p_positions[i];
    v.normal = (i < p_normals.size()) ? p_normals[i] : glm::vec3(0.0f);
    v.color = glm::vec3(1.0f, 1.0f, 1.0f);
    v.textureUV = (i < p_texUVs.size()) ? p_texUVs[i] : glm::vec2(0.0f);
    vertices.push_back(v);
  }
  return vertices;
}

std::vector<glm::vec2> Model::GroupFloatsVec2(const std::vector<float>& p_floats) {
  std::vector<glm::vec2> vectors;
  for (size_t i = 0; i < p_floats.size(); i += 2)
    vectors.push_back(glm::vec2(p_floats[i], p_floats[i + 1]));
  return vectors;
}

std::vector<glm::vec3> Model::GroupFloatsVec3(const std::vector<float>& p_floats) {
  std::vector<glm::vec3> vectors;
  for (size_t i = 0; i < p_floats.size(); i += 3)
    vectors.push_back(glm::vec3(p_floats[i], p_floats[i + 1], p_floats[i + 2]));
  return vectors;
}

void Model::Draw(Shader& p_shader, Camera& p_camera) {
  for (auto& mesh : c_meshes) {
    mesh->Draw(p_shader, p_camera);
  }
}
