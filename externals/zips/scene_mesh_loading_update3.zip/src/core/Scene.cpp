#include "core/Scene.h"

#include <iostream>

Scene::Scene(int p_viewportHeight, int p_viewportWidth) {
  c_camera = std::make_unique<Camera>(p_viewportHeight, p_viewportWidth, glm::vec3(0.0f, 0.0f, 2.0f));

  // Scene owns its own shader rather than borrowing Core's, so it stays a
  // fully self-contained unit - the same reasoning as SceneView owning its
  // own mShader in mesh_loader_full_project.
  c_shader = std::make_unique<Shader>("resource/Shaders/default.vert", "resource/Shaders/default.frag");
}

Scene::~Scene() {
  c_shader->Delete();
}

bool Scene::LoadModel(const std::string& p_filepath) {
  try {
    c_models.push_back(std::make_unique<Model>(p_filepath));
    return true;
  } catch (const std::exception& e) {
    std::cerr << "Scene::LoadModel failed for '" << p_filepath << "': " << e.what() << std::endl;
    return false;
  }
}

void Scene::Update(GLFWwindow* p_window, double p_deltaTime) {
  c_camera->HandleInputs(p_window, p_deltaTime);
  c_camera->UpdateMatrix(45.0f, 0.1f, 100.0f);
}

void Scene::Render() {
  c_shader->Activate();
  for (auto& model : c_models) {
    model->Draw(*c_shader, *c_camera);
  }
}
