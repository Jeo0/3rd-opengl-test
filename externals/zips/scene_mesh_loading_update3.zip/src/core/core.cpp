#include "core/core.h"
#include "GLFW/glfw3.h"
#include <iostream>

Core::Core() :  windowObj(800, 800, "gademNoice", NULL, NULL, {0.01f, 0.24f, 0.45f, 1.0f})
{
    Init();
}

Core::~Core() { Cleanup(); }

void Core::Run() {
    // The Main Game/Render Loop
    while (!glfwWindowShouldClose(windowObj.ID)) {
        float mDeltaTime = cLimiter.StartFrame();
        Update(mDeltaTime);
        Render(mDeltaTime);         // buffer swap
        glfwPollEvents(); // polling is a must after buffer swap

        cLimiter.EndFrame();
    }
}

void Core::Init() {

    // ============================
    // open gl opengl settings
    glEnable(GL_DEPTH_TEST);

    // ============================
    // object instantiations
    //
    scene = std::make_unique<Scene>(windowObj.Height, windowObj.Width);
    setset = std::make_unique<Settings>(cLimiter);

    // TODO: no glTF sample asset exists in resource/ yet - point this at a
    // real .gltf (+ its sibling .bin) once you have one to test against.
    // LoadModel() logs and no-ops on failure rather than crashing, so this
    // is safe to leave pointed at a placeholder for now.
    scene->LoadModel("resource/Models/example/example.gltf");
}


void Core::Update(double p_deltaTime) {
    /*  LOGIC TINGS */
    // settings
    setset->LoadSettings(cLimiter);

    // mouse input ++++============================== goback here
    windowObj.HandleMouseInput();
    scene->Update(windowObj.ID, p_deltaTime);

    // debug ===================== REMOVE
    std::cout << "FPS: " << (1.0 / p_deltaTime) << '\n';

}


void Core::Render(double p_deltaTime) {
    /*  RENDER TINGS */
    // opengl things
    glClearColor(bgColor[0], bgColor[1], bgColor[2], bgColor[3]); // tanggalin to
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    scene->Render();

    glfwSwapBuffers(windowObj.ID);
}

void Core::Cleanup() {
    glfwDestroyWindow(windowObj.ID);
    glfwTerminate();
}
