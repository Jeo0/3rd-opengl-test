#pragma once

#include <memory>
#include <string>
#include <unordered_map>
#include <vector>

#include "core/simdjson.h"
#include "gl/Camera.h"
#include "gl/Mesh.h"
#include "gl/Texture.h"
#include "gl/shaderClass.h"

// Loads a glTF 2.0 asset (a .gltf JSON scene description alongside a .bin
// buffer file) into a set of drawable Mesh instances.
//
// This deliberately does NOT use Assimp - it mirrors the hand-rolled
// "Model" class from the VictorGordan / LearnOpenGL tutorial series, but:
//   - retargeted onto THIS project's Mesh / Texture / Camera / Shader types
//     (their constructors and Draw() signatures differ from the tutorial's)
//   - uses simdjson (simdjson::dom, since we need random/repeated access into
//     the document rather than a single forward pass) instead of nlohmann::json
//   - shares Textures via a filepath-keyed cache of shared_ptr<Texture>
//     rather than copying Texture by value (this project's Texture owns a
//     live GL handle and can't safely be value-copied)
//
// A Model owns its own Meshes (each mesh already carries its node transform
// via Mesh::SetTransform), so Draw() is just "draw every mesh in this model".
class Model {
public:
  explicit Model(const std::string& p_filepath);
  ~Model() = default;

  void Draw(Shader& p_shader, Camera& p_camera);

private:
  std::string c_filepath;
  std::string c_directory; // folder containing the .gltf, for resolving relative uris

  std::vector<unsigned char> c_binaryData;

  simdjson::dom::parser c_parser;
  simdjson::dom::element c_json;

  std::vector<std::unique_ptr<Mesh>> c_meshes;

  // keyed by resolved image path, so the same image is only ever loaded once
  // per Model, even if referenced by several primitives.
  std::unordered_map<std::string, std::shared_ptr<Texture>> c_loadedTextures;

  std::vector<unsigned char> LoadBinaryData();

  // Walks the glTF node hierarchy starting at p_nodeIndex, accumulating each
  // node's local TRS into p_parentTransform, and loads a Mesh for every node
  // that references one.
  void TraverseNode(unsigned int p_nodeIndex, const glm::mat4& p_parentTransform = glm::mat4(1.0f));

  void LoadMesh(unsigned int p_meshIndex, const glm::mat4& p_transform);

  std::vector<float> GetFloats(simdjson::dom::element p_accessor);
  std::vector<GLuint> GetIndices(simdjson::dom::element p_accessor);
  // Reads a primitive's material and returns only the texture(s) it actually
  // references (baseColorTexture / metallicRoughnessTexture), not every
  // image in the file. Materials that use a flat baseColorFactor instead of
  // a texture (common - not every material has one) correctly yield no
  // textures here.
  std::vector<std::shared_ptr<Texture>> GetTextures(simdjson::dom::element p_material);

  // Resolves textures[p_textureIndex].source -> images[source].uri, loading
  // (or returning from cache) the Texture it points to.
  std::shared_ptr<Texture> LoadTextureByIndex(uint64_t p_textureIndex, const std::string& p_textureType);

  std::vector<Vertex> AssembleVertices(
      const std::vector<glm::vec3>& p_positions,
      const std::vector<glm::vec3>& p_normals,
      const std::vector<glm::vec2>& p_texUVs);

  static std::vector<glm::vec2> GroupFloatsVec2(const std::vector<float>& p_floats);
  static std::vector<glm::vec3> GroupFloatsVec3(const std::vector<float>& p_floats);
};
