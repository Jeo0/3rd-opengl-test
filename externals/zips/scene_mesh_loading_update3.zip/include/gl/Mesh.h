
#include "Camera.h"
#include "VAO.h"
#include "VBO.h"
#include "gl/Texture.h"
#include "shaderClass.h"
#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include <memory>
#include <vector>

class Mesh {
public:
  std::vector<Vertex> c_vertices;
  std::vector<GLuint> c_indices;
  // shared_ptr (not unique_ptr): a texture loaded from one glTF/model file is
  // frequently reused across several meshes/primitives. Texture owns a live
  // GL handle, so it can't be value-copied - sharing ownership via shared_ptr
  // is how multiple meshes reference the same loaded texture without a
  // reload or a double-delete.
  std::vector<std::shared_ptr<Texture>> c_textures;
  glm::mat4 c_modelPos = glm::mat4(1.0);       // position of the mesh within the scene

  // We gonna store here in VAOO what we will be drawing
  VAO VAOO;



  Mesh(std::vector<Vertex> &p_vertices, std::vector<GLuint> &p_indices,
       std::vector<std::shared_ptr<Texture>> p_textures);
  ~Mesh();

  void Draw(Shader &p_shader, Camera& p_camera);
  void SetPosition(const glm::vec3& p_position);
  // Full transform (translation + rotation + scale collapsed to one matrix).
  // Model/glTF node hierarchies carry more than a plain translation, so this
  // sits alongside SetPosition rather than replacing it.
  void SetTransform(const glm::mat4& p_transform);

};
