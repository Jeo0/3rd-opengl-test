#pragma once

#include <memory>
#include <string>
#include <vector>

#include "GLFW/glfw3.h"
#include "gl/Camera.h"
#include "gl/Model.h"
#include "gl/shaderClass.h"

// Owns everything needed to load and draw 3D content: the camera, the shader
// used to render it, and whatever Models have been loaded in.
//
// On purpose, Scene knows NOTHING about ImGui, windows, or panels - it only
// renders into whatever framebuffer happens to be currently bound (right now:
// the default framebuffer, same as Core used to draw directly). That's what
// lets it become a "SceneView" panel later (see mesh_loader_full_project's
// nui::SceneView for the shape that takes): the panel would give it an
// offscreen framebuffer and put the resulting texture in an ImGui::Image()
// call - nothing in Scene itself would need to change.
//
// Input is intentionally NOT owned here either; Core still owns the GLFWwindow
// and forwards deltaTime/window handle in, mirroring how Camera::HandleInputs
// already takes a GLFWwindow* rather than owning one.
class Scene {
private:
  std::unique_ptr<Camera> c_camera;
  std::unique_ptr<Shader> c_shader;
  std::vector<std::unique_ptr<Model>> c_models;

public:
  Scene(int p_viewportHeight, int p_viewportWidth);
  ~Scene();

  // Loads a glTF (.gltf + .bin) file and adds it to the scene.
  // Swallows load failures (missing file, malformed JSON, etc.) rather than
  // crashing the app - logs to stderr and simply doesn't add anything.
  // Useful right now since there's no file-browser UI yet to only ever pass
  // valid paths in.
  bool LoadModel(const std::string& p_filepath);

  void Update(GLFWwindow* p_window, double p_deltaTime);
  void Render();

  Camera* GetCamera() { return c_camera.get(); }
};
