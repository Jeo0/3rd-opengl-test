# Scene / glTF mesh-loading update

Drop these files into your project at the matching paths (they overwrite
existing files 1:1, same folder layout as `include/` and `src/`). Your
Makefile globs all `.cpp` under `src/` automatically, so `Model.cpp` will get
picked up without touching the Makefile.

## What changed and why

- **`include/gl/Mesh.h` / `src/gl/Mesh.cpp`**
  `c_textures` is now `vector<shared_ptr<Texture>>` instead of
  `vector<unique_ptr<Texture>>`, so multiple meshes can share one loaded
  texture (this is what `Model`'s texture cache relies on). Also added
  `SetTransform(glm::mat4)` alongside the existing `SetPosition(vec3)`, since
  glTF nodes carry full translation/rotation/scale, not just a position.

- **`include/gl/Model.h` / `src/gl/Model.cpp`** *(new)*
  A hand-rolled glTF 2.0 loader - JSON scene graph (`.gltf`) + binary buffer
  (`.bin`). Adapted from the VictorGordan/LearnOpenGL tutorial's `Model`
  class, but retargeted onto your own `Mesh` / `Texture` / `Camera` / `Shader`
  types, and using `simdjson::dom` (not `nlohmann::json` like the tutorial -
  see note below) for JSON access.

- **`include/core/Scene.h` / `src/core/Scene.cpp`**
  Your `Scene` stub, filled in. Owns the `Camera`, its own `Shader`, and a
  list of loaded `Model`s. `LoadModel(path)` catches load failures (missing
  file, bad JSON) and logs instead of crashing. **Deliberately has no ImGui
  or window knowledge** - it only draws into whatever framebuffer is
  currently bound. That's what lets it become a panel later without any
  internal changes (see the design notes in the chat reply).

- **`include/core/core.h` / `src/core/core.cpp`**
  `Core` no longer owns the camera, the scene shader, or the mesh list
  directly - that's all `Scene`'s job now. `Core` is left owning: the window,
  frame limiter, settings, and the loop. `Update`/`Render` just forward into
  `Scene`.

## Before you build

1. **You need a sample glTF asset.** Neither `my_project` nor `tutorial_2`
   shipped one. Grab something small from the
   [Khronos glTF-Sample-Models repo](https://github.com/KhronosGroup/glTF-Sample-Models)
   (e.g. `Box` or `BoxTextured`) - you want the `glTF` variant (JSON + `.bin`
   + loose image files), not `glTF-Binary` (`.glb`, which this loader doesn't
   handle) or `glTF-Embedded`.
2. Put it somewhere like `resource/Models/<name>/<name>.gltf` and point
   `Core::Init()`'s `scene->LoadModel(...)` call at it.
3. This has been **syntax-checked but not compiled/linked or run** (this
   environment doesn't have your OpenGL/GLFW toolchain). Build it and send me
   whatever the compiler says if something doesn't line up - simdjson's API
   surface is large enough that a small signature mismatch wouldn't be
   surprising.

## Known limitations of this first pass (fine for "dabbling", worth knowing)

- Only reads the first primitive of each mesh (`primitives.at(0)`), same
  simplification the tutorial makes.
- Only handles external image URIs (`"uri": "texture.png"`), not
  base64-embedded or bufferView-embedded images.
- Assumes node 0 is the scene root rather than reading `JSON["scene"]`.
- Index component type 5121 (`UNSIGNED_BYTE`) is now handled correctly -
  worth knowing the tutorial's original code actually checked for `5122`
  there, which isn't a valid glTF index type (that's signed `SHORT`); fixed
  in this version.

None of these matter for getting something on screen; they'd matter once you
start loading more complex/varied assets, which is presumably when you'd be
reaching for Assimp anyway.
