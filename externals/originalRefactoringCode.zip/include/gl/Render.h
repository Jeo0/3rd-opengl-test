
#include "GLAD/glad.h"
#include "glm/trigonometric.hpp"
#include "shaderClass.h"
#include "Camera.h"
class Object {
    public:

};


class RenderPass {
public:
    virtual ~RenderPass() = default;
    virtual void Draw(const std::vector<Object*>& p_objects, Camera& p_camera) override;
    bool c_enabled = true;
};

class PointOverlayPass : public RenderPass {
public:
    PointOverlayPass(Shader* p_shader);

    void Draw(const std::vector<Object*>& p_objects, Camera& p_camera);

    float     c_size  = 6.0f;
    glm::vec3 c_color = glm::vec3(1.0f);
    bool      c_xray  = false;

private:
    Shader* c_shader;
};
